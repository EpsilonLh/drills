# Assessment results

Every prescribed seed is shown. Levels are mapped LUT depth.

| Circuit | Seed | Status | Episodes | LUTs | Levels | Feasible | Training seconds |
|---|---:|---|---:|---:|---:|---|---:|
| i2c | 0 | complete | 100 | 301 | 4 | True | 169.07809390900002 |
| i2c | 1 | complete | 100 | 307 | 4 | True | 164.49543008600017 |
| i2c | 2 | complete | 100 | 306 | 4 | True | 167.0568837120001 |

| Circuit | Complete / required | Feasible / required | LUTs mean ± std | Levels mean ± std |
|---|---|---|---|---|
| i2c | 3/3 | 3/3 | 304.667 ± 2.625 | 4.000 ± 0.000 |

No aggregate score is computed if any prescribed seed is incomplete or infeasible.
Each completed seed reports its best feasible training-time mapping, not an independent test-set score.
Training time is elapsed wall time for episode initialization, ABC/Yosys search and network updates; excludes checkpoint export, model initialization, resyn2 and final CEC. Concurrent runs share machine resources.

| Circuit | Training seconds total (sum of seeds) | Training seconds mean |
|---|---:|---:|
| i2c | 500.63040770700024 | 166.8768025690001 |
