# Assessment results

Every prescribed seed is shown. Levels are mapped LUT depth.

| Circuit | Seed | Status | Episodes | LUTs | Levels | Feasible | Training seconds |
|---|---:|---|---:|---:|---:|---|---:|
| i2c | 0 | complete | 100 | 300 | 4 | True | 149.24493112599998 |
| i2c | 1 | complete | 100 | 307 | 4 | True | 144.13433630200007 |
| i2c | 2 | complete | 100 | 306 | 4 | True | 147.29540779500013 |

| Circuit | Complete / required | Feasible / required | LUTs mean ± std | Levels mean ± std |
|---|---|---|---|---|
| i2c | 3/3 | 3/3 | 304.333 ± 3.091 | 4.000 ± 0.000 |

No aggregate score is computed if any prescribed seed is incomplete or infeasible.
Each completed seed reports its best feasible training-time mapping, not an independent test-set score.
Training time is elapsed wall time for episode initialization, ABC/Yosys search and network updates; excludes checkpoint export, model initialization, resyn2 and final CEC. Concurrent runs share machine resources.

| Circuit | Training seconds total (sum of seeds) | Training seconds mean |
|---|---:|---:|
| i2c | 440.6746752230002 | 146.89155840766674 |
