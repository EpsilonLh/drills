// Benchmark "/Users/zhan/Downloads/test/DRiLLS/benchmarks/int2float" written by ABC on Fri Sep 25 14:16:52 2026

module \/Users/zhan/Downloads/test/DRiLLS/benchmarks/int2float  ( 
    \B[0] , \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] , \B[8] ,
    \B[9] , \B[10] ,
    \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2]   );
  input  \B[0] , \B[1] , \B[2] , \B[3] , \B[4] , \B[5] , \B[6] , \B[7] ,
    \B[8] , \B[9] , \B[10] ;
  output \M[0] , \M[1] , \M[2] , \M[3] , \E[0] , \E[1] , \E[2] ;
  wire new_n21, new_n22, new_n23, new_n24, new_n25, new_n26, new_n28,
    new_n29, new_n30, new_n31, new_n32, new_n33, new_n34, new_n35, new_n36,
    new_n37, new_n38, new_n39, new_n40, new_n42, new_n43, new_n44, new_n45,
    new_n46, new_n47, new_n48, new_n50, new_n52, new_n53, new_n54, new_n55,
    new_n56, new_n58, new_n59, new_n60, new_n61, new_n62, new_n63;
  assign \M[0]  = (\B[10]  & ~\B[6]  & \B[7] ) | (~new_n26 & \B[6] ) | (~\B[10]  & (~new_n21 | new_n23));
  assign new_n21 = (~\B[9]  | (\B[5]  & \B[6] ) | (~\B[5]  & ~\B[6] )) & (~new_n22 | ~\B[5]  | \B[6] );
  assign new_n22 = (~\B[1]  | ~\B[2] ) & ((\B[1]  & ((~\B[4]  & ~\B[7] ) | (~\B[8]  & ~\B[3]  & \B[4] ))) | (\B[2]  & ~\B[7]  & ~\B[8] ));
  assign new_n23 = ~\B[9]  & ((~new_n24 & ~\B[5] ) | (\B[5]  & ~\B[4]  & \B[8] ) | (~new_n25 & ~\B[8] ));
  assign new_n24 = (~\B[4]  | ~\B[8] ) & ((~\B[0]  & (~\B[1]  | ~\B[4] )) | \B[6]  | \B[7]  | (\B[0]  & (\B[4]  ? \B[1]  : \B[8] )));
  assign new_n25 = (~\B[3]  | ((\B[4]  | ~\B[7] ) & (\B[2]  | \B[7]  | ~\B[1]  | ~\B[5] ))) & (~\B[7]  | \B[3]  | ~\B[4] );
  assign new_n26 = (\B[7]  | (~\B[10]  & (\B[8]  | \B[9]  | (\B[2]  ^ ~\B[3] )))) & (~\B[9]  | ~\B[8]  | ~\B[10] );
  assign \M[1]  = ~new_n28 & ~new_n40 & (\B[10]  | (~new_n31 & new_n35));
  assign new_n28 = (~\B[6]  | ~\B[7] ) & ~\B[8]  & (\B[10]  | (~\B[7]  & (new_n29 | ~new_n30)));
  assign new_n29 = ~\B[3]  & ((~\B[4]  & \B[6]  & ~\B[9] ) | (~\B[1]  & \B[5]  & ~\B[6] ));
  assign new_n30 = (\B[2]  | ((\B[4]  | ~\B[6]  | \B[9] ) & (\B[6]  | \B[3]  | ~\B[5] ))) & (~\B[6]  | \B[9]  | ~\B[2]  | ~\B[3]  | ~\B[4] );
  assign new_n31 = ~\B[5]  & (~new_n32 | (~\B[6]  & (new_n33 | ~new_n34)));
  assign new_n32 = (\B[7]  | ~\B[9] ) & (\B[8]  | \B[9]  | ~\B[7]  | (\B[3]  & \B[4] ));
  assign new_n33 = \B[4]  & ~\B[7]  & (\B[0]  ? (\B[1]  & \B[2] ) : ~\B[2] );
  assign new_n34 = (~\B[8]  | \B[9] ) & (\B[1]  | ((\B[2]  | \B[7] ) & (\B[4]  | \B[9] )));
  assign new_n35 = ~new_n39 & (~\B[5]  | (~new_n38 & (~new_n37 | (~new_n36 & ~\B[7] ))));
  assign new_n36 = \B[1]  & \B[2] ;
  assign new_n37 = \B[3]  & (\B[4]  ? (~\B[8]  & ~\B[9] ) : (~\B[6]  & ~\B[7] ));
  assign new_n38 = \B[6]  & (\B[8]  | \B[9] ) & (\B[7]  | ~\B[9] ) & (~\B[8]  | \B[4]  | \B[9] );
  assign new_n39 = ~\B[6]  & ((~\B[7]  & \B[9] ) | (\B[8]  & ~\B[4]  & ~\B[9] ));
  assign new_n40 = \B[8]  & ~\B[9]  & \B[10]  & (\B[9]  | (\B[8]  & \B[6]  & \B[7] ));
  assign \M[2]  = ~new_n48 | (~\B[10]  & (new_n47 | (~\B[9]  & (new_n42 | ~new_n46))));
  assign new_n42 = ~\B[8]  & (~new_n45 | (~\B[7]  & (new_n44 | (~new_n43 & \B[2] ))));
  assign new_n43 = (~\B[1]  | ((\B[3]  | ~\B[4]  | ~\B[0]  | \B[6] ) & (~\B[5]  | ~\B[3]  | \B[4] ))) & (\B[5]  | ((\B[4]  | \B[6] ) & ((\B[0]  & \B[1] ) | ~\B[3]  | ~\B[4] )));
  assign new_n44 = \B[4]  & ((~\B[3]  & \B[5] ) | (~\B[6]  & ~\B[2]  & \B[3] ));
  assign new_n45 = (\B[3]  & \B[4] ) ? ((\B[1]  | ~\B[5]  | \B[6] ) & (~\B[6]  | ~\B[2]  | \B[5] )) : (~\B[5]  | ~\B[6] );
  assign new_n46 = (\B[4]  & \B[5] ) ? ((~\B[3]  | \B[6]  | ~\B[7] ) & (~\B[6]  | \B[2]  | \B[7] )) : (~\B[6]  | ~\B[7] );
  assign new_n47 = \B[8]  & ((~\B[6]  & \B[7] ) | (\B[4]  & \B[5]  & \B[6]  & ~\B[7] ));
  assign new_n48 = (~\B[10]  | (~\B[9]  & (~\B[8]  | ~\B[6]  | ~\B[7] ))) & ((\B[8]  & \B[5]  & \B[7] ) | ~\B[9]  | (~\B[8]  & (~\B[6]  | ~\B[5]  | ~\B[7] )));
  assign \M[3]  = \B[9]  | \B[10]  | new_n50 | \B[3] ;
  assign new_n50 = (\B[4]  | \B[7]  | \B[8]  | \B[5]  | \B[6] ) & (~\B[4]  | ~\B[8]  | \B[2]  | ~\B[6]  | ~\B[5]  | ~\B[7] );
  assign \E[0]  = \B[10]  | (new_n55 & (\B[8]  | (~new_n52 & ~new_n53 & ~\B[9] )));
  assign new_n52 = (~\B[6]  | \B[7] ) & (~\B[4]  | ((\B[5]  | \B[7] ) & (~\B[3]  | ((~new_n36 | \B[7] ) & (~\B[5]  | ~\B[6] )))));
  assign new_n53 = \B[2]  & ~new_n54 & \B[3] ;
  assign new_n54 = (~\B[4]  | ~\B[5]  | ~\B[6]  | \B[7] ) & (~\B[0]  | ~\B[1]  | \B[5]  | \B[6] );
  assign new_n55 = \B[9]  ? (\B[6]  & \B[5]  & \B[7] ) : (~\B[6]  | ~\B[7]  | new_n56 | ~\B[4]  | ~\B[5] );
  assign new_n56 = \B[3]  ? ~\B[8]  : ~\B[2] ;
  assign \E[1]  = (new_n61 & ~new_n63) | \B[9]  | \B[10]  | (~new_n58 & \B[4] );
  assign new_n58 = (~\B[2]  | (~new_n60 & (~new_n59 | ~\B[8] ))) & (~\B[3]  | ~new_n59 | ~\B[8] );
  assign new_n59 = \B[6]  & \B[5]  & \B[7] ;
  assign new_n60 = ~\B[8]  & \B[0]  & \B[1]  & \B[3]  & ~\B[5]  & ~\B[7] ;
  assign new_n61 = ~new_n62 & ~\B[7]  & ~\B[8] ;
  assign new_n62 = \B[2]  & \B[3]  & \B[4]  & \B[5]  & \B[6] ;
  assign new_n63 = ~\B[5]  & ~\B[6] ;
  assign \E[2]  = ~new_n61 | \B[9]  | \B[10] ;
endmodule


