# Assessment results

Every prescribed seed is shown. Levels are mapped LUT depth.

| Circuit | Seed | Status | Episodes | LUTs | Levels | Feasible | Training seconds |
|---|---:|---|---:|---:|---:|---|---:|
| int2float | 0 | complete | 100 | 45 | 3 | True | 92.51763279299998 |
| int2float | 1 | complete | 100 | 44 | 3 | True | 88.55737182600002 |
| int2float | 2 | complete | 100 | 43 | 3 | True | 90.50899587900003 |
| i2c | 0 | complete | 100 | 300 | 4 | True | 244.89085529099998 |
| i2c | 1 | complete | 100 | 305 | 4 | True | 233.87890633500027 |
| i2c | 2 | complete | 100 | 306 | 4 | True | 243.74012337800013 |
| max | 0 | complete | 100 | 769 | 41 | True | 484.6657304560002 |
| max | 1 | complete | 100 | 775 | 41 | True | 478.76351525399974 |
| max | 2 | complete | 100 | 773 | 41 | True | 478.2297305380001 |

| Circuit | Complete / required | Feasible / required | LUTs mean ± std | Levels mean ± std |
|---|---|---|---|---|
| int2float | 3/3 | 3/3 | 44.000 ± 0.816 | 3.000 ± 0.000 |
| i2c | 3/3 | 3/3 | 303.667 ± 2.625 | 4.000 ± 0.000 |
| max | 3/3 | 3/3 | 772.333 ± 2.494 | 41.000 ± 0.000 |

No aggregate score is computed if any prescribed seed is incomplete or infeasible.
Each completed seed reports its best feasible training-time mapping, not an independent test-set score.
Training time is elapsed wall time for episode initialization, ABC/Yosys search and network updates; excludes checkpoint export, model initialization, resyn2 and final CEC. Concurrent runs share machine resources.

| Circuit | Training seconds total (sum of seeds) | Training seconds mean |
|---|---:|---:|
| int2float | 271.584000498 | 90.52800016600001 |
| i2c | 722.5098850040004 | 240.83662833466678 |
| max | 1441.658976248 | 480.55299208266666 |
