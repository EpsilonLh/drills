# Assessment results

Every prescribed seed is shown. Levels are mapped LUT depth.

| Circuit | Seed | Status | Episodes | LUTs | Levels | Feasible | Training seconds |
|---|---:|---|---:|---:|---:|---|---:|
| i2c | 0 | complete | 100 | 286 | 4 | True | 548.2061839620003 |
| i2c | 1 | complete | 100 | 290 | 4 | True | 534.4862349600002 |
| i2c | 2 | complete | 100 | 292 | 4 | True | 544.1068325 |

| Circuit | Complete / required | Feasible / required | LUTs mean ± std | Levels mean ± std |
|---|---|---|---|---|
| i2c | 3/3 | 3/3 | 289.333 ± 2.494 | 4.000 ± 0.000 |

No aggregate score is computed if any prescribed seed is incomplete or infeasible.
Each completed seed reports its best feasible training-time mapping, not an independent test-set score.
Training time is elapsed wall time for episode initialization, ABC/Yosys search and network updates; excludes checkpoint export, model initialization, resyn2 and final CEC. Concurrent runs share machine resources.

| Circuit | Training seconds total (sum of seeds) | Training seconds mean |
|---|---:|---:|
| i2c | 1626.7992514220005 | 542.2664171406668 |
