# Assessment results

Every prescribed seed is shown. Levels are mapped LUT depth.

| Circuit | Seed | Status | Episodes | LUTs | Levels | Feasible | Training seconds |
|---|---:|---|---:|---:|---:|---|---:|
| i2c | 0 | complete | 100 | 285 | 4 | True | 591.3671335470003 |
| i2c | 1 | complete | 100 | 291 | 4 | True | 573.9677661699997 |
| i2c | 2 | complete | 100 | 287 | 4 | True | 582.0395429610002 |

| Circuit | Complete / required | Feasible / required | LUTs mean ± std | Levels mean ± std |
|---|---|---|---|---|
| i2c | 3/3 | 3/3 | 287.667 ± 2.494 | 4.000 ± 0.000 |

No aggregate score is computed if any prescribed seed is incomplete or infeasible.
Each completed seed reports its best feasible training-time mapping, not an independent test-set score.
Training time is elapsed wall time for episode initialization, ABC/Yosys search and network updates; excludes checkpoint export, model initialization, resyn2 and final CEC. Concurrent runs share machine resources.

| Circuit | Training seconds total (sum of seeds) | Training seconds mean |
|---|---:|---:|
| i2c | 1747.3744426780004 | 582.4581475593335 |
