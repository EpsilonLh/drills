# Assessment results

Every prescribed seed is shown. Levels are mapped LUT depth.

| Circuit | Seed | Status | Episodes | LUTs | Levels | Feasible | Training seconds |
|---|---:|---|---:|---:|---:|---|---:|
| int2float | 0 | complete | 100 | 45 | 3 | True | 85.04925783700004 |
| int2float | 1 | complete | 100 | 44 | 3 | True | 81.836220491 |
| int2float | 2 | complete | 100 | 43 | 3 | True | 83.477426378 |
| i2c | 0 | complete | 100 | 300 | 4 | True | 197.47692896100014 |
| i2c | 1 | complete | 100 | 305 | 4 | True | 189.32257678800013 |
| i2c | 2 | complete | 100 | 306 | 4 | True | 195.2062330389999 |
| max | 0 | complete | 100 | 769 | 41 | True | 502.85648466499987 |
| max | 1 | complete | 100 | 775 | 41 | True | 501.6508722959997 |
| max | 2 | complete | 100 | 773 | 41 | True | 501.89187058499965 |

| Circuit | Complete / required | Feasible / required | LUTs mean ± std | Levels mean ± std |
|---|---|---|---|---|
| int2float | 3/3 | 3/3 | 44.000 ± 0.816 | 3.000 ± 0.000 |
| i2c | 3/3 | 3/3 | 303.667 ± 2.625 | 4.000 ± 0.000 |
| max | 3/3 | 3/3 | 772.333 ± 2.494 | 41.000 ± 0.000 |

No aggregate score is computed if any prescribed seed is incomplete or infeasible.
Each completed seed reports its best feasible training-time mapping, not an independent test-set score.
Training time is elapsed wall time for episode initialization, ABC/Yosys search and network updates; excludes checkpoint export, model initialization, resyn2 and final CEC. Concurrent runs share machine resources.

| Circuit | Training seconds total (sum of seeds) | Training seconds mean |
|---|---:|---:|
| int2float | 250.36290470600005 | 83.45430156866668 |
| i2c | 582.0057387880001 | 194.00191292933337 |
| max | 1506.399227545999 | 502.13307584866635 |
